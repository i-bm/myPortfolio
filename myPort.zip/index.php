<?php include 'layout/header.php'; ?>
<?php include 'layout/navigation.php'; ?>
<main>
	<!---================
	======INTRO========	 -->
	<section>
		<div class="container">
			<div class="row">
			<div class="col-8 mx-auto mt-5">
				<div class="card mb-3" style="border:none">
  <div class="row no-gutters">
    <div class="col-md-4">
      <img src="assets/img/isaac.jpg" class="card-img img-fluid" alt="isaac-boakye-manu">
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title">Hi there! I'm</h5>
        <h2 style="line-height: 30px" class="font-weight-bold">Isaac Boakye-Manu</h2>
    	<h3 class="font-weight-light">Web Developer</h3>
    	<ul class="list-group list-group-flush">
		  <a href="mailto:isaac.boakyemanu@gmail.com"><li class="list-group-item pl-0 pb-0 border-none"><i class="fa fa-envelope-o" aria-hidden="true"></i>&nbsp; isaac.boakyemanu@gmail.com</li></a>	
		  <a href="tel:+233247924225"><li class="list-group-item pl-0 border-none pb-0"><i class="fa fa-phone" aria-hidden="true"></i>&nbsp; +233 24 792 4225</li></a>
		  <li class="list-group-item pl-0 border-none"><i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp; Paradise Street, Accra, Ghana</li>
		</ul>
      <ul class="list-group list-group-horizontal-sm">
  <a href="https://github.com/i-bm" target="_blank"><li class="list-group-item border-none pl-0"><i class="fa fa-github" style="font-size: 1.5rem" aria-hidden="true"></i></li></a>
  <a href="https://linkedin.com/in/i-bm" target="_blank"><li class="list-group-item border-none pl-0"><i class="fa fa-linkedin" style="font-size: 1.5rem"  aria-hidden="true"></i></li></a>
  <!-- <li class="list-group-item"><a href="#"><i class="fa fa-github" aria-hidden="true"></i></a></li> -->
</ul>
      </div>
    </div>
  </div>
</div>
			</div>
			</div>
			
		</div>
	</section>

<section id="portfolio" class="projects bg-gray border-top border-bottom">
	<div class="container">
		<h2>My Portfolio</h2>
		<div class="row">
			<div class="col-4 mt-3">
				<div class="card shadow-sm  mb-5 bg-white rounded">
					<img src="https://images.unsplash.com/photo-1457305237443-44c3d5a30b89?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1053&q=80" class="card-img-top img-fluid" alt="...">
					<div class="card-body">
						<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
						<a href="#" class="btn btn-primary">Code</a>
						<a href="#" class="btn btn-danger">Website</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<section id="skills" class="pt-5 about">
	<div class="container">
<h2>About Me</h2>
<p>I'm a very fast learner and highly passionate about technology, how it works and what makes it work.. I do not know it all, however, I know how to get my hands around to get the things done.</p>

		<h2 class="mt-5">My Web Development Skills </h2>
		<div class="row">
			<div class="col-1">
				<img src="assets/img/html.jpg" class="img-fluid" alt="" />
			</div>
			<div class="col-1">
				<img src="assets/img/css.jpg" class="img-fluid" alt="" />
			</div>
			<div class="col-1">
				<img src="assets/img/js.jpg" class="img-fluid" alt="" />
			</div>
			<div class="col-1">
				<img src="assets/img/jquery.jpg" class="img-fluid" alt="" />
			</div>
			<div class="col-1">
				<img src="assets/img/html.jpg" class="img-fluid" alt="" />
			</div>
			<div class="col-1">
				<img src="assets/img/html.jpg" class="img-fluid" alt="" />
			</div>
			<div class="col-1">
				<img src="assets/img/html.jpg" class="img-fluid" alt="" />
			</div>
			<div class="col-1">
				<img src="assets/img/html.jpg" class="img-fluid" alt="" />
			</div>
			<div class="col-1">
				<img src="assets/img/html.jpg" class="img-fluid" alt="" />
			</div>
			
			<div class="col-1">
				<img src="assets/img/html.jpg" class="img-fluid" alt="" />
			</div>
		</div>

	</div>
</section>

</main>


<?php include 'layout/footer.php' ; ?>