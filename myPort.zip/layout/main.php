<?php include 'header.php' ; ?>
<?php include 'navigation.php' ; ?>
<?php include $content; ?>
<?php include 'footer.php' ; ?>